<? if ($post->post_parent) {
	$children = wp_list_pages("title_li=&child_of=".$post->post_parent."&echo=0"); 
  } else {
  	$children = wp_list_pages("title_li=&child_of=".$post->ID."&echo=0");
  }
  if ($children) { ?>

	<nav class="sub-nav">
		<h2><a href="<? echo get_post($post->post_parent)->permalink; ?>"><? echo get_post($post->post_parent)->post_title; ?></a></h2>
		  <ul>
		  	<? echo $children; ?>
		  </ul>
	</nav>
<? } ?>