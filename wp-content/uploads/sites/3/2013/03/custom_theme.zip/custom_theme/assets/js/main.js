$(document).ready(function(){
	//JS here
	});