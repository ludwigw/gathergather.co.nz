<?php get_header(); ?>


<h1>Welcome to our Website!</h1>

<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
	<? the_content(); ?>
<?php endwhile; endif; ?>

</div><!-- #main -->

<aside>
	<? get_template_part("ctas"); ?>
</aside>




<?php get_footer(); ?>