<? 
	$ctas = MRP_get_related_posts( $post->ID, true, true, 'cta' );
	$op = $post;

	if($ctas){foreach($ctas as $key => $cta) { $post = $cta; ?>
			<div class="promo">
				<h3><? the_title(); ?></h3>
				<? the_content(); ?>
			</div>
<?	 	}
	} $post = $op;
?>