<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the id=main div and all content after
 *
 * @package WordPress
 * @subpackage Twenty_Eleven
 * @since Twenty Eleven 1.0
 */
?>


	<footer class="foot">
		<nav><?php wp_nav_menu( array( 'theme_location' => 'primary', 'container' => false ) ); ?></nav>
	</footer>

</div> <!--container-->

<?php wp_footer(); ?>

</body>
</html>