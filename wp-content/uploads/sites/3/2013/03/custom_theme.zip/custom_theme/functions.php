<?
register_nav_menu( 'primary', "Main Menu");
?>