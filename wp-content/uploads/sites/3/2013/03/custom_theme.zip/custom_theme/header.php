<?php
/**
 * The Header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="main">
 *
 * @package WordPress
 * @subpackage Twenty_Eleven
 * @since Twenty Eleven 1.0
 */
?>

<!DOCTYPE html>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php global $page, $paged; wp_title( '&laquo;', true, 'right' ); bloginfo( 'name' ); ?></title>

<link rel="stylesheet" media="all" href="<?php bloginfo( 'template_directory' ); ?>/assets/css/main.css">

<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
	<div id="container">
	<header role="banner" class="banner">
		<h1>
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
				<?php bloginfo( 'name' ); ?>
			</a>
		</h1>
		<nav id="access" role="navigation">
			<?php wp_nav_menu( array( 'theme_location' => 'primary', 'container' => false, 'depth'=>'1') ); ?>
		</nav>
	</header>


	<div role="main" class="main">